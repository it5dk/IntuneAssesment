#  BEGIN AUTODOC HEADER
#  File: EntraGroups-NameTune-Mapping.ps1
#  Description: (edit inside USER NOTES below)
# 
#  BEGIN AUTODOC META
#  Version: 0.0.0.1
#  Last-Updated: 2026-02-12 19:45:31
#  Managed-By: autosave.ps1
#  END AUTODOC META
# 
#  BEGIN USER NOTES
#  Your notes here. We will NEVER change this block.
#  END USER NOTES
#  END AUTODOC HEADER


<#
EntraGroups-NameTune-Mapping.ps1 (ModernPlus3 Dropdown + Count Fixes)

What this version does:
- Connects to Microsoft Graph (Entra ID) and pulls all groups
- Builds a SuggestedName (NameTune-ish) with NO spaces (uses -/_/. based on -Separator)
- Builds SuggestedCategory (Prefix-Type, e.g. INTUNE-APP)
- Splits groups into With Members / Without Members (memberCount via /members/$count)
- Generates a modern HTML report with:
  - Tabs (With/Without members)
  - Global search, sortable columns
  - Dropdown filters (SuggestedCategory dropdown w/ counts + type-to-filter box)
  - Export CSV/JSON (browser-side for filtered rows)
  - Copy SuggestedName per row
- Opens the report in Microsoft Edge

Fixes included:
- Forces Graph results to arrays using @() so .Count never fails
- Uses @($var).Count everywhere counting occurs
- Makes scriptDir safe in PowerShell ISE / VSCode / direct run

Permissions:
- Group.Read.All
#>

[CmdletBinding()]
param(
  [string]$HtmlPath = ".\EntraGroups_Report.html",
  [string]$LogPath  = ".\EntraGroups_Report_Debug.log",

  # NameTune-ish options
  [string]$Prefix = "INTUNE",
  [ValidateSet("Dash","Underscore","Dot","None")]
  [string]$Separator = "Dash",
  [ValidateSet("AsTyped","UPPERCASE","lowercase","CamelCase")]
  [string]$Case = "UPPERCASE",

  [int]$MaxDescWords = 4,
  [int]$MaxRetry = 5,

  # Optional: skip member counting (faster) => all groups go to "Without Members" tab with MemberCount=0
  [switch]$FastMode
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Log {
  param([string]$Msg)
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Msg
  Write-Host $line
  if (-not [string]::IsNullOrWhiteSpace($LogPath)) {
    Add-Content -Path $LogPath -Value $line -ErrorAction SilentlyContinue
  }
}

# Resolve script directory safely
$scriptDir = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($scriptDir)) { $scriptDir = (Get-Location).Path }

if (-not [System.IO.Path]::IsPathRooted($HtmlPath)) { $HtmlPath = Join-Path $scriptDir $HtmlPath }
if (-not [System.IO.Path]::IsPathRooted($LogPath))  { $LogPath  = Join-Path $scriptDir $LogPath }

Remove-Item -Path $LogPath -ErrorAction SilentlyContinue

Write-Log "Starting. HtmlPath=$HtmlPath"

function Get-SeparatorChar {
  param([string]$Sep)
  switch ($Sep) {
    "Dash"       { "-" }
    "Underscore" { "_" }
    "Dot"        { "." }
    "None"       { "" }
  }
}

function Apply-Case {
  param([string]$Text, [string]$CaseMode)
  if ([string]::IsNullOrWhiteSpace($Text)) { return "" }
  switch ($CaseMode) {
    "AsTyped"   { return $Text }
    "UPPERCASE" { return $Text.ToUpperInvariant() }
    "lowercase" { return $Text.ToLowerInvariant() }
    "CamelCase" {
      if ($Text -cmatch '^[A-Z0-9]+$') { return $Text }
      $ti = (Get-Culture).TextInfo
      return $ti.ToTitleCase($Text.ToLowerInvariant())
    }
  }
}

function Normalize-Code {
  param([string]$Token)
  if ([string]::IsNullOrWhiteSpace($Token)) { return "" }
  $t = $Token.Trim()

  if ($t -match '^(D|DEVICE)$') { return "D" }
  if ($t -match '^(U|USER)$')   { return "U" }

  switch -Regex ($t.ToUpperInvariant()) {
    '^WIN(DOWS)?$'     { return "WIN" }
    '^MAC(OS)?$'       { return "MAC" }
    '^(IOS|IPADOS)$'   { return "IOS" }
    '^(AND|ANDROID)$'  { return "AND" }
    default            { }
  }

  switch -Regex ($t.ToUpperInvariant()) {
    '^REQ(UIRED)?$'    { return "REQ" }
    '^AVAIL(ABLE)?$'   { return "AVAIL" }
    '^UNINST(ALL)?$'   { return "UNINST" }
    default            { }
  }

  return $t
}

# NO SPACES: returns tokens joined by separator (default "-")
function Sanitize-Desc {
  param([string]$Desc, [string]$SeparatorChar, [int]$MaxWords = 4)

  if ([string]::IsNullOrWhiteSpace($Desc)) { return "" }

  $d = $Desc.Trim()
  $d = ($d -replace '[-_.]+', ' ')
  $d = ($d -replace '\s+', ' ').Trim()

  $words = $d.Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries)
  if ($words.Count -gt $MaxWords) { $words = $words[0..($MaxWords-1)] }

  if ([string]::IsNullOrEmpty($SeparatorChar)) { return ($words -join '') }
  return ($words -join $SeparatorChar)
}

function Try-Parse-NameTuneLikeName {
  param([string]$DisplayName, [string]$Prefix)

  $tokens = ($DisplayName -split '[-_.]' | ForEach-Object { $_.Trim() }) | Where-Object { $_ -ne "" }
  if ($tokens.Count -lt 2) { return $null }
  if ($tokens[0].ToUpperInvariant() -ne $Prefix.ToUpperInvariant()) { return $null }

  $type = $tokens[1]
  $descParts = New-Object System.Collections.Generic.List[string]
  $target = $null; $os = $null; $assign = $null; $region = $null

  $i = 2
  while ($i -lt $tokens.Count) {
    $tok = Normalize-Code $tokens[$i]
    if (-not $target -and $tok -match '^(D|U)$') { $target = $tok; $i++; continue }
    if ($target -and -not $os -and $tok -match '^(WIN|MAC|IOS|AND)$') { $os = $tok; $i++; continue }
    if ($os -and -not $assign -and $tok -match '^(REQ|AVAIL|UNINST)$') { $assign = $tok; $i++; continue }
    if ($os -and ($i -eq $tokens.Count - 1) -and -not $region) { $region = $tokens[$i]; break }
    $descParts.Add($tokens[$i]); $i++
  }

  $desc = ($descParts -join " ").Trim()
  return [pscustomobject]@{ Prefix=$Prefix; Type=$type; Desc=$desc; Target=$target; OS=$os; Assign=$assign; Region=$region }
}

function Infer-FieldsFromText {
  param([string]$Text)
  $t = ($Text ?? "").ToLowerInvariant()

  $target = if ($t -match '\bdevice(s)?\b') { "D" }
            elseif ($t -match '\buser(s)?\b') { "U" }
            else { "" }

  $os = if ($t -match '\bwin(dows)?\b') { "WIN" }
        elseif ($t -match '\bmac(os)?\b') { "MAC" }
        elseif ($t -match '\bios\b|\bipados\b') { "IOS" }
        elseif ($t -match '\bandroid\b') { "AND" }
        else { "" }

  $type = ""
  if ($t -match '\brole\b|\brbac\b') { $type = "ROLE" }
  elseif ($t -match '\bapp\b|\bapplication\b') { $type = "APP" }
  elseif ($t -match '\bpolicy\b') { $type = "POLICY" }
  elseif ($t -match '\bconfig\b|\bconfiguration\b') { $type = "CONFIG" }
  elseif ($t -match '\bca\b|\bconditional access\b') { $type = "CA" }
  elseif ($t -match '\bscript\b|\bpowershell\b') { $type = "SCRIPT" }

  $assign = if ($t -match '\brequired\b') { "REQ" }
            elseif ($t -match '\bavailable\b') { "AVAIL" }
            elseif ($t -match '\buninstall\b|\bremove\b') { "UNINST" }
            else { "" }

  $region = if ($t -match '\beu\b|\beurope\b') { "EU" }
            elseif ($t -match '\bdk\b|\bdenmark\b') { "DK" }
            elseif ($t -match '\bus\b|\busa\b|\bunited states\b') { "US" }
            elseif ($t -match '\bglobal\b') { "GLOBAL" }
            else { "" }

  return [pscustomobject]@{ Type=$type; Target=$target; OS=$os; Assign=$assign; Region=$region }
}

function Build-NameTuneGroupName {
  param(
    [string]$Prefix,[string]$Type,[string]$Desc,[string]$Target,[string]$OS,[string]$Assign,[string]$Region,
    [string]$SeparatorChar,[string]$CaseMode
  )

  $parts = New-Object System.Collections.Generic.List[string]
  foreach ($p in @($Prefix,$Type,$Desc,$Target,$OS,$Assign,$Region)) {
    if ([string]::IsNullOrWhiteSpace($p)) { continue }
    $norm = Normalize-Code $p
    $norm = if (-not [string]::IsNullOrEmpty($SeparatorChar)) { ($norm -replace '\s+', $SeparatorChar) } else { ($norm -replace '\s+', '') }
    $parts.Add((Apply-Case -Text $norm -CaseMode $CaseMode))
  }

  if ($SeparatorChar -eq "") { return ($parts -join "") }
  return ($parts -join $SeparatorChar)
}

function Invoke-WithRetry {
  param([Parameter(Mandatory=$true)][scriptblock]$Action,[int]$Max = 5)
  for ($i=1; $i -le $Max; $i++) {
    try { return & $Action }
    catch {
      if ($i -eq $Max) { throw }
      $sleep = [Math]::Min(30, 2 * $i)
      Write-Log "WARN: Graph call failed (attempt $i/$Max). Retrying in ${sleep}s. $($_.Exception.Message)"
      Start-Sleep -Seconds $sleep
    }
  }
}

function Get-GroupMemberCount {
  param([string]$GroupId, [int]$Max = 5)
  if ($FastMode) { return 0 }

  $uri = "https://graph.microsoft.com/v1.0/groups/$GroupId/members/`$count"
  $raw = Invoke-WithRetry -Max $Max -Action {
    Invoke-MgGraphRequest -Method GET -Uri $uri -Headers @{ "ConsistencyLevel"="eventual" }
  }

  if ($raw -is [string]) { if ($raw.Trim() -match '^\d+$') { return [int]$raw.Trim() } }
  $digits = ([string]$raw -replace '[^\d]', '')
  if ($digits -match '^\d+$') { return [int]$digits }
  return 0
}

function Get-GroupTypeLabel {
  param([string[]]$GroupTypes,[bool]$MailEnabled,[bool]$SecurityEnabled)
  if ($GroupTypes -contains "Unified") { return "Microsoft365" }
  if ($MailEnabled -and $SecurityEnabled) { return "MailEnabledSecurity" }
  if (-not $MailEnabled -and $SecurityEnabled) { return "Security" }
  if ($MailEnabled -and -not $SecurityEnabled) { return "Distribution" }
  return "Unknown"
}

# -------------------------
# Graph setup + validation
# -------------------------
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph)) {
  Write-Log "Installing Microsoft.Graph for current user..."
  Install-Module Microsoft.Graph -Scope CurrentUser -Force
}
Import-Module Microsoft.Graph -ErrorAction Stop

Write-Log "Connecting to Microsoft Graph with scope Group.Read.All..."
Connect-MgGraph -Scopes @("Group.Read.All") | Out-Null

$ctx = Get-MgContext
if (-not $ctx) { throw "Not connected to Graph. Connect-MgGraph failed." }

Write-Log ("Connected. TenantId={0} Account={1}" -f $ctx.TenantId, $ctx.Account)
if (-not ($ctx.Scopes -contains "Group.Read.All")) {
  throw "Missing required scope Group.Read.All. Current scopes: $($ctx.Scopes -join ', ')"
}

$sepChar = Get-SeparatorChar -Sep $Separator

# -------------------------
# Pull groups
# -------------------------
Write-Log "Fetching groups from Graph..."
$groups = Invoke-WithRetry -Max $MaxRetry -Action {
  Get-MgGroup -All -Property @(
    "id","displayName","description",
    "groupTypes","membershipRule",
    "mailEnabled","securityEnabled",
    "onPremisesSyncEnabled","onPremisesLastSyncDateTime","onPremisesSecurityIdentifier"
  ) -ConsistencyLevel eventual
}

# COUNT FIX: force to array so .Count ALWAYS exists
$groups = @($groups)

if (-not $groups -or $groups.Count -eq 0) {
  throw "No groups returned. This usually means missing admin consent or no groups."
}
Write-Log ("Fetched {0} groups." -f $groups.Count)

# -------------------------
# Build rows
# -------------------------
$rows = New-Object System.Collections.Generic.List[object]
$total = $groups.Count   # safe now
$idx = 0

foreach ($g in $groups) {
  $idx++
  if (($idx % 10) -eq 0 -or $idx -eq 1 -or $idx -eq $total) {
    Write-Progress -Activity "Building report (counting members)" -Status "$idx / $total" -PercentComplete ([int](($idx / [double]$total) * 100))
  }

  $displayName = $g.DisplayName
  $desc = $g.Description

  $isSynced = $false
  if ($g.OnPremisesSyncEnabled -eq $true) { $isSynced = $true }
  elseif ($null -ne $g.OnPremisesLastSyncDateTime) { $isSynced = $true }
  elseif (-not [string]::IsNullOrWhiteSpace($g.OnPremisesSecurityIdentifier)) { $isSynced = $true }

  $isDynamic = ($g.GroupTypes -contains "DynamicMembership") -or (-not [string]::IsNullOrWhiteSpace($g.MembershipRule))
  $membershipType = if ($isDynamic) { "Dynamic" } else { "Manual" }

  $groupType = Get-GroupTypeLabel -GroupTypes $g.GroupTypes -MailEnabled ([bool]$g.MailEnabled) -SecurityEnabled ([bool]$g.SecurityEnabled)

  $suggestedType = ""
  $suggestedTarget = ""
  $suggestedOS = ""
  $suggestedAssign = ""
  $suggestedRegion = ""
  $needsReview = $false

  $suggestedName = ""
  $parsed = Try-Parse-NameTuneLikeName -DisplayName $displayName -Prefix $Prefix

  if ($null -ne $parsed) {
    $suggestedType   = $parsed.Type
    $suggestedTarget = $parsed.Target
    $suggestedOS     = $parsed.OS
    $suggestedAssign = $parsed.Assign
    $suggestedRegion = $parsed.Region

    $cleanDesc = Sanitize-Desc -Desc $parsed.Desc -SeparatorChar $sepChar -MaxWords $MaxDescWords
    $suggestedName = Build-NameTuneGroupName -Prefix $Prefix -Type $suggestedType -Desc $cleanDesc -Target $suggestedTarget -OS $suggestedOS `
      -Assign $suggestedAssign -Region $suggestedRegion -SeparatorChar $sepChar -CaseMode $Case
  }
  else {
    $inf = Infer-FieldsFromText -Text "$displayName $desc"
    $suggestedType   = $inf.Type
    $suggestedTarget = $inf.Target
    $suggestedOS     = $inf.OS
    $suggestedAssign = $inf.Assign
    $suggestedRegion = $inf.Region

    $cleanDesc = Sanitize-Desc -Desc $displayName -SeparatorChar $sepChar -MaxWords $MaxDescWords
    $suggestedName = Build-NameTuneGroupName -Prefix $Prefix -Type $suggestedType -Desc $cleanDesc -Target $suggestedTarget -OS $suggestedOS `
      -Assign $suggestedAssign -Region $suggestedRegion -SeparatorChar $sepChar -CaseMode $Case

    if ([string]::IsNullOrWhiteSpace($suggestedType) -or [string]::IsNullOrWhiteSpace($suggestedTarget) -or [string]::IsNullOrWhiteSpace($suggestedOS)) {
      $needsReview = $true
      $suggestedName = $suggestedName + $sepChar + (Apply-Case -Text "REVIEW" -CaseMode $Case)
    }
  }

  # SuggestedCategory like INTUNE-APP, INTUNE-ROLE
  $suggestedCategory = ""
  if (-not [string]::IsNullOrWhiteSpace($suggestedType)) {
    $suggestedCategory = Build-NameTuneGroupName -Prefix $Prefix -Type $suggestedType -Desc "" -Target "" -OS "" -Assign "" -Region "" -SeparatorChar $sepChar -CaseMode $Case
  }

  $memberCount = Get-GroupMemberCount -GroupId $g.Id -Max $MaxRetry

  $rows.Add([pscustomobject]@{
    DisplayName       = $displayName
    SuggestedName     = $suggestedName

    SuggestedCategory = $suggestedCategory
    SuggestedType     = $suggestedType
    SuggestedTarget   = $suggestedTarget
    SuggestedOS       = $suggestedOS
    SuggestedAssign   = $suggestedAssign
    SuggestedRegion   = $suggestedRegion
    NeedsReview       = if ($needsReview) { "Yes" } else { "No" }

    GroupType         = $groupType
    MembershipType    = $membershipType
    Synced            = if ($isSynced) { "Yes" } else { "No" }
    MemberCount       = $memberCount
    Description       = $desc
    Id                = $g.Id

    _hasMembers       = ($memberCount -gt 0)
  }) | Out-Null
}

Write-Progress -Activity "Building report (counting members)" -Completed
Write-Log ("Built {0} rows." -f @($rows).Count)

$cols = @(
  "DisplayName","SuggestedName",
  "SuggestedCategory","SuggestedType","SuggestedTarget","SuggestedOS","SuggestedAssign","SuggestedRegion","NeedsReview",
  "GroupType","MembershipType","Synced","MemberCount","Description","Id"
)

# COUNT FIX: force to arrays before using .Count again
$rowsArr = @($rows)

$withMembers    = @($rowsArr | Where-Object { $_._hasMembers } | Sort-Object DisplayName | Select-Object $cols)
$withoutMembers = @($rowsArr | Where-Object { -not $_._hasMembers } | Sort-Object DisplayName | Select-Object $cols)

Write-Log ("WithMembers={0}, WithoutMembers={1}" -f @($withMembers).Count, @($withoutMembers).Count)

$withJson    = ($withMembers    | ConvertTo-Json -Depth 8)
$withoutJson = ($withoutMembers | ConvertTo-Json -Depth 8)

# -------------------------
# HTML (dropdown, no chips) + counts + type-to-filter for categories
# -------------------------
$full = @"
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Entra ID Groups Report</title>
<style>
  :root{--panel: rgba(255,255,255,.06);--text: rgba(255,255,255,.92);--muted: rgba(255,255,255,.68);--line: rgba(255,255,255,.12);--shadow: 0 10px 30px rgba(0,0,0,.35);--radius: 16px;--btn: rgba(255,255,255,.10);--btnOn: rgba(255,255,255,.16);}
  *{box-sizing:border-box}
  body{margin:0;font-family:"Segoe UI",system-ui,-apple-system,Arial,sans-serif;background:radial-gradient(1200px 800px at 10% 10%, #142347 0%, #0b1220 50%, #070b14 100%);color:var(--text);}
  header{position:sticky;top:0;z-index:10;backdrop-filter:blur(12px);background:linear-gradient(to bottom, rgba(11,18,32,.92), rgba(11,18,32,.60));border-bottom:1px solid var(--line);}
  .wrap{max-width:1320px;margin:0 auto;padding:16px 18px;}
  .titleRow{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;}
  h1{margin:0;font-size:18px}
  .meta{margin:6px 0 0 0;color:var(--muted);font-size:12px}
  .controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
  .search{width:min(520px,90vw);background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);color:var(--text);padding:10px 12px;border-radius:12px;outline:none}
  .btn{border:1px solid rgba(255,255,255,.14);background:var(--btn);color:var(--text);padding:10px 12px;border-radius:12px;cursor:pointer;font-size:12px;display:inline-flex;gap:8px;align-items:center}
  .btn:hover{background:var(--btnOn)}
  .tabs{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}
  .tab{border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);color:var(--text);padding:8px 10px;border-radius:999px;cursor:pointer;font-size:12px}
  .tab.active{background:rgba(255,255,255,.14);border-color:rgba(255,255,255,.22)}
  .filters{margin-top:10px;display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px}
  @media (max-width:1100px){.filters{grid-template-columns:repeat(3,minmax(0,1fr))}}
  @media (max-width:640px){.filters{grid-template-columns:1fr}}
  .sel,.miniInput{width:100%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);color:var(--text);padding:10px;border-radius:12px;outline:none;font-size:12px}
  .sel option{background:#0b1220}
  .miniLabel{font-size:11px;color:var(--muted);margin:0 0 6px 4px}
  .cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:18px 0 14px}
  @media (max-width:980px){.cards{grid-template-columns:repeat(2,minmax(0,1fr))}}
  @media (max-width:520px){.cards{grid-template-columns:1fr}}
  .card{background:var(--panel);border:1px solid rgba(255,255,255,.12);border-radius:var(--radius);padding:12px;box-shadow:var(--shadow)}
  .card .k{color:var(--muted);font-size:12px} .card .v{font-size:18px;font-weight:600;margin-top:4px}
  .tableWrap{background:var(--panel);border:1px solid rgba(255,255,255,.12);border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow)}
  table{width:100%;border-collapse:collapse}
  thead th{position:sticky;top:252px;background:rgba(18,28,50,.92);backdrop-filter:blur(10px);border-bottom:1px solid rgba(255,255,255,.14);text-align:left;font-size:12px;color:rgba(255,255,255,.82);padding:10px;cursor:pointer;white-space:nowrap}
  tbody td{border-bottom:1px solid rgba(255,255,255,.08);padding:10px;font-size:12px;vertical-align:top}
  tbody tr:hover{background:rgba(255,255,255,.06)}
  .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,"Liberation Mono",monospace}
  .badge{display:inline-flex;align-items:center;padding:4px 8px;border-radius:999px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);font-size:11px;white-space:nowrap}
  .mutedTxt{color:var(--muted)}
  .actionsCol{width:128px}
  .copyBtn{border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);color:var(--text);padding:6px 8px;border-radius:10px;cursor:pointer;font-size:12px}
  .copyBtn:hover{background:rgba(255,255,255,.12)}
  .toast{position:fixed;bottom:14px;right:14px;background:rgba(20,35,71,.92);border:1px solid rgba(255,255,255,.16);padding:10px 12px;border-radius:12px;box-shadow:var(--shadow);display:none;z-index:50;font-size:12px}
</style>
</head>
<body>
<header>
  <div class="wrap">
    <div class="titleRow">
      <div>
        <h1>Entra ID Groups — SuggestedCategory Dropdown</h1>
        <div class="meta">Generated: $(Get-Date) • Prefix: $Prefix</div>
      </div>
      <div class="controls">
        <input id="search" class="search" placeholder="Search…" />
        <button class="btn" id="btnClear">✖ Clear</button>
        <button class="btn" id="btnCsv">⬇ CSV</button>
        <button class="btn" id="btnJson">⬇ JSON</button>
      </div>
    </div>

    <div class="tabs">
      <div class="tab active" data-tab="with">With Members <span class="mutedTxt" id="countWith"></span></div>
      <div class="tab" data-tab="without">Without Members <span class="mutedTxt" id="countWithout"></span></div>
    </div>

    <div class="filters">
      <div>
        <div class="miniLabel">Filter SuggestedCategory list</div>
        <input class="miniInput" id="catSearch" placeholder="Type to filter categories (ANDROID, AVD, RING…)" />
        <select class="sel" id="fSuggestedCategory"><option value="">SuggestedCategory (All)</option></select>
      </div>
      <select class="sel" id="fSuggestedType"><option value="">SuggestedType (All)</option></select>
      <select class="sel" id="fSuggestedTarget"><option value="">SuggestedTarget (All)</option></select>
      <select class="sel" id="fSuggestedOS"><option value="">SuggestedOS (All)</option></select>
      <select class="sel" id="fGroupType"><option value="">GroupType (All)</option></select>
      <select class="sel" id="fMembershipType"><option value="">MembershipType (All)</option></select>
    </div>
  </div>
</header>

<main>
  <div class="wrap">
    <div class="cards">
      <div class="card"><div class="k">Total groups</div><div class="v" id="totalGroups"></div></div>
      <div class="card"><div class="k">With members</div><div class="v" id="withMembers"></div></div>
      <div class="card"><div class="k">Without members</div><div class="v" id="withoutMembers"></div></div>
      <div class="card"><div class="k">Needs review</div><div class="v" id="needsReview"></div></div>
    </div>

    <div class="tableWrap">
      <table id="tbl">
        <thead>
          <tr>
            <th data-key="Actions" class="actionsCol">Actions</th>
            <th data-key="DisplayName">DisplayName</th>
            <th data-key="SuggestedName">SuggestedName</th>
            <th data-key="SuggestedCategory">SuggestedCategory</th>
            <th data-key="GroupType">GroupType</th>
            <th data-key="MembershipType">MembershipType</th>
            <th data-key="Synced">Synced</th>
            <th data-key="MemberCount">MemberCount</th>
            <th data-key="Description">Description</th>
            <th data-key="Id">Id</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>

    <div class="toast" id="toast"></div>
  </div>
</main>

<script>
const data = { with: $withJson, without: $withoutJson };
const allCols = ["Actions","DisplayName","SuggestedName","SuggestedCategory","GroupType","MembershipType","Synced","MemberCount","Description","Id"];
const state = { tab:"with", q:"", sortKey:"DisplayName", sortDir:"asc", filters:{SuggestedCategory:"",SuggestedType:"",SuggestedTarget:"",SuggestedOS:"",GroupType:"",MembershipType:""} };

function escapeHtml(s){ if(s===null||s===undefined) return ""; return String(s).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;"); }
function toast(msg){ const t=document.getElementById("toast"); t.textContent=msg; t.style.display="block"; clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>t.style.display="none",1600); }
function activeRows(){ return data[state.tab]||[]; }
function rowMatchesFilters(r){ for(const k of Object.keys(state.filters)){ const v=state.filters[k]; if(!v) continue; if(String(r[k]??"")!==v) return false; } return true; }
function rowMatchesSearch(r){ const q=state.q.trim().toLowerCase(); if(!q) return true; return allCols.some(k=>k!=="Actions" && String(r[k]??"").toLowerCase().includes(q)); }

function applyAll(rows){
  let out=rows.filter(rowMatchesFilters).filter(rowMatchesSearch);
  const k=state.sortKey; const dir=state.sortDir==="asc"?1:-1;
  return out.slice().sort((a,b)=>{
    if(k==="Actions") return 0;
    const av=a[k], bv=b[k];
    const an=(typeof av==="number")?av:(String(av??"").match(/^\d+$/)?Number(av):null);
    const bn=(typeof bv==="number")?bv:(String(bv??"").match(/^\d+$/)?Number(bv):null);
    if(an!==null && bn!==null) return (an-bn)*dir;
    const as=String(av??"").toLowerCase(), bs=String(bv??"").toLowerCase();
    if(as<bs) return -1*dir; if(as>bs) return 1*dir; return 0;
  });
}

function render(){
  const filtered=applyAll(activeRows());
  const all=data.with.length+data.without.length;
  const needsReview=[...data.with,...data.without].filter(r=>String(r.NeedsReview||"")==="Yes").length;
  document.getElementById("totalGroups").textContent=all;
  document.getElementById("withMembers").textContent=data.with.length;
  document.getElementById("withoutMembers").textContent=data.without.length;
  document.getElementById("needsReview").textContent=needsReview;
  document.getElementById("countWith").textContent="("+data.with.length+")";
  document.getElementById("countWithout").textContent="("+data.without.length+")";

  const tb=document.querySelector("#tbl tbody"); tb.innerHTML="";
  for(const r of filtered){
    const tr=document.createElement("tr");
    const tdA=document.createElement("td");
    tdA.innerHTML='<button class="copyBtn" data-copy="'+escapeHtml(r.SuggestedName??"")+'">Copy</button>';
    tr.appendChild(tdA);

    const cells=[
      '<b>'+escapeHtml(r.DisplayName)+'</b>',
      '<span class="mono">'+escapeHtml(r.SuggestedName??"")+'</span>'+(String(r.NeedsReview)==="Yes"?' <span class="badge mono">REVIEW</span>':''),
      '<span class="badge mono">'+escapeHtml(r.SuggestedCategory??"")+'</span>',
      '<span class="badge">'+escapeHtml(r.GroupType??"")+'</span>',
      '<span class="badge">'+escapeHtml(r.MembershipType??"")+'</span>',
      '<span class="badge">'+escapeHtml(r.Synced??"")+'</span>',
      '<span class="mono">'+escapeHtml(r.MemberCount??"")+'</span>',
      '<span class="mutedTxt">'+escapeHtml(r.Description??"")+'</span>',
      '<span class="mono mutedTxt">'+escapeHtml(r.Id??"")+'</span>'
    ];
    for(const html of cells){ const td=document.createElement("td"); td.innerHTML=html; tr.appendChild(td); }
    tb.appendChild(tr);
  }

  document.querySelectorAll(".copyBtn").forEach(b=>{
    b.addEventListener("click", async ()=>{
      const v=b.getAttribute("data-copy")||"";
      try{ await navigator.clipboard.writeText(v); toast("Copied SuggestedName"); }
      catch(e){
        const ta=document.createElement("textarea"); ta.value=v; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); document.body.removeChild(ta);
        toast("Copied SuggestedName");
      }
    });
  });
}

function download(filename, text, mime){
  const blob=new Blob([text],{type:(mime||"text/plain;charset=utf-8")});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a"); a.href=url; a.download=filename; document.body.appendChild(a); a.click();
  setTimeout(()=>{ URL.revokeObjectURL(url); document.body.removeChild(a); },0);
}
function toCSV(rows){
  const headers=["DisplayName","SuggestedName","SuggestedCategory","GroupType","MembershipType","Synced","MemberCount","Description","Id"];
  const esc=(v)=>{ const s=String(v??""); if(s.includes('"')||s.includes(",")||s.includes("\n")) return '"'+s.replaceAll('"','""')+'"'; return s; };
  const lines=[headers.join(",")];
  for(const r of rows){ lines.push(headers.map(h=>esc(r[h])).join(",")); }
  return lines.join("\n");
}
function uniq(allRows,key){ const s=new Set(); for(const r of allRows){ const v=String(r[key]??""); if(v) s.add(v);} return [...s]; }
function fillSelectWithCounts(id,key,predicateText){
  const sel=document.getElementById(id); const keepFirst=sel.options[0].outerHTML; sel.innerHTML=keepFirst;
  const all=[...data.with,...data.without];
  const map=new Map();
  for(const r of all){
    const v=String(r[key]??""); if(!v) continue;
    if(predicateText){ const t=predicateText.toLowerCase(); if(!v.toLowerCase().includes(t)) continue; }
    map.set(v,(map.get(v)||0)+1);
  }
  const values=[...map.keys()].sort((a,b)=>a.localeCompare(b));
  for(const v of values){ const o=document.createElement("option"); o.value=v; o.textContent=`${v} (${map.get(v)})`; sel.appendChild(o); }
}
function refreshFilterOptions(){
  const all=[...data.with,...data.without];
  fillSelectWithCounts("fSuggestedCategory","SuggestedCategory",document.getElementById("catSearch").value||"");

  const fill=(id,key)=>{
    const sel=document.getElementById(id); const keepFirst=sel.options[0].outerHTML; sel.innerHTML=keepFirst;
    uniq(all,key).sort((a,b)=>a.localeCompare(b)).forEach(v=>{ const o=document.createElement("option"); o.value=v; o.textContent=v; sel.appendChild(o); });
  };
  fill("fSuggestedType","SuggestedType"); fill("fSuggestedTarget","SuggestedTarget"); fill("fSuggestedOS","SuggestedOS");
  fill("fGroupType","GroupType"); fill("fMembershipType","MembershipType");
}
function bindFilterSelect(id,key){
  document.getElementById(id).addEventListener("change",()=>{ state.filters[key]=document.getElementById(id).value||""; render(); });
}
function clearAll(){
  state.q=""; document.getElementById("search").value="";
  for(const k of Object.keys(state.filters)) state.filters[k]="";
  ["fSuggestedCategory","fSuggestedType","fSuggestedTarget","fSuggestedOS","fGroupType","fMembershipType"].forEach(id=>document.getElementById(id).value="");
  document.getElementById("catSearch").value="";
  refreshFilterOptions(); render(); toast("Cleared");
}

document.getElementById("search").addEventListener("input",(e)=>{ state.q=e.target.value||""; render(); });
document.getElementById("catSearch").addEventListener("input",()=>{ const cur=state.filters.SuggestedCategory||""; refreshFilterOptions(); document.getElementById("fSuggestedCategory").value=cur; });

document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>{ document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active")); t.classList.add("active"); state.tab=t.dataset.tab; render(); }));
document.querySelectorAll("#tbl thead th").forEach(th=>th.addEventListener("click",()=>{ const key=th.dataset.key; if(!key||key==="Actions") return; if(state.sortKey===key){ state.sortDir=(state.sortDir==="asc")?"desc":"asc"; } else { state.sortKey=key; state.sortDir="asc"; } render(); }));

bindFilterSelect("fSuggestedCategory","SuggestedCategory");
bindFilterSelect("fSuggestedType","SuggestedType");
bindFilterSelect("fSuggestedTarget","SuggestedTarget");
bindFilterSelect("fSuggestedOS","SuggestedOS");
bindFilterSelect("fGroupType","GroupType");
bindFilterSelect("fMembershipType","MembershipType");

document.getElementById("btnCsv").addEventListener("click",()=>{ const rows=applyAll(activeRows()); download("EntraGroups_"+state.tab+"_filtered.csv",toCSV(rows),"text/csv;charset=utf-8"); toast("CSV exported ("+rows.length+" rows)"); });
document.getElementById("btnJson").addEventListener("click",()=>{ const rows=applyAll(activeRows()); download("EntraGroups_"+state.tab+"_filtered.json",JSON.stringify(rows,null,2),"application/json;charset=utf-8"); toast("JSON exported ("+rows.length+" rows)"); });
document.getElementById("btnClear").addEventListener("click",clearAll);

refreshFilterOptions(); render();
</script>
</body>
</html>
"@

Set-Content -Path $HtmlPath -Value $full -Encoding UTF8
Write-Log "HTML report written: $HtmlPath"
Write-Log "Opening in Edge..."
Start-Process "msedge.exe" -ArgumentList "`"$HtmlPath`""
Write-Log "Done."
Write-Log "Debug log: $LogPath"

