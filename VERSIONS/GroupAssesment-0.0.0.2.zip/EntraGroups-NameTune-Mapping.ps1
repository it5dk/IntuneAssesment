#  BEGIN AUTODOC HEADER
#  File: EntraGroups-NameTune-Mapping.ps1
#  Description: (edit inside USER NOTES below)
# 
#  BEGIN AUTODOC META
#  Version: 0.0.0.2
#  Last-Updated: 2026-02-12 23:02:45
#  Managed-By: autosave.ps1
#  END AUTODOC META
# 
#  BEGIN USER NOTES
#  Your notes here. We will NEVER change this block.
#  END USER NOTES
#  END AUTODOC HEADER

# --- 1. Configuration ---
$Prefix = "INTUNE"
$Separator = "-"
$Case = "UPPERCASE"
$MaxDescWords = 4
$ReportPath = "$PSScriptRoot\EntraGroupsReport.html"

# --- 2. Handle File Overwrite Safely ---
if (Test-Path $ReportPath) {
    Write-Host "Existing report found. Preparing to overwrite..." -ForegroundColor Yellow
    try {
        # Remove Read-Only attribute if it exists
        Set-ItemProperty $ReportPath -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
        # Force delete the old file to ensure a clean slate
        Remove-Item $ReportPath -Force -ErrorAction Stop
    } catch {
        Write-Error "Could not remove the existing file. Please ensure '$ReportPath' is not open in another program."
        return
    }
}

# --- 3. Connect ---
if (!(Get-MgContext)) { Connect-MgGraph -Scopes "Group.Read.All", "Directory.Read.All" }

Write-Host "Gathering Groups..." -ForegroundColor Cyan
$Groups = Get-MgGroup -All -Property "Id","DisplayName","GroupTypes","MailEnabled","SecurityEnabled","OnPremisesSyncEnabled","MembershipRule"

# --- 4. Data Processing ---
$ReportData = foreach ($Group in $Groups) {
    Write-Host "Processing: $($Group.DisplayName)" -ForegroundColor Gray
    
    $Count = (Get-MgGroupMember -GroupId $Group.Id -All -ErrorAction SilentlyContinue).Count
    $MemberCount = if ($null -eq $Count) { 0 } else { [int]$Count }

    $GType = if ("Unified" -in $Group.GroupTypes) { "Microsoft365" }
             elseif ($Group.MailEnabled -and $Group.SecurityEnabled) { "MailEnabledSecurity" }
             elseif ($Group.MailEnabled) { "Distribution" }
             else { "Security" }

    $MType = if ($Group.GroupTypes -contains "DynamicMembership" -or $Group.MembershipRule) { "Dynamic" } else { "Manual" }
    $IsSynced = if ($Group.OnPremisesSyncEnabled) { "Yes" } else { "No" }

    $CleanName = $Group.DisplayName -replace '[^a-zA-Z0-9 ]', ''
    $Words = $CleanName.Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries)
    $Desc = ($Words | Select-Object -First $MaxDescWords) -join $Separator
    $SuggName = "$Prefix$Separator$Desc"
    if ($Case -eq "UPPERCASE") { $SuggName = $SuggName.ToUpper() }

    $Cat = if ($Group.DisplayName -match "App") { "APP" } elseif ($Group.DisplayName -match "Config") { "CFG" } else { "GEN" }

    [PSCustomObject]@{
        DisplayName    = $Group.DisplayName
        SuggestedName  = $SuggName
        GroupType      = $GType
        MembershipType = $MType
        MemberCount    = $MemberCount
        Synced         = $IsSynced
        Category       = "$Prefix$Separator$Cat"
    }
}

# --- 5. Export to CSV string safely ---
$TempCsv = "$PSScriptRoot\temp_data.csv"
$ReportData | Export-Csv -Path $TempCsv -NoTypeInformation -Encoding utf8 -Force
$CsvString = Get-Content $TempCsv -Raw
Remove-Item $TempCsv -Force

# --- 6. HTML Template ---
$HtmlTemplate = @'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Entra ID Groups Report</title>
    <style>
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f8f9fa; padding: 20px; }
        .container { background: white; border-radius: 8px; padding: 25px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); max-width: 1300px; margin: auto; }
        .tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #eee; }
        .tab { padding: 10px 20px; cursor: pointer; font-weight: bold; color: #555; }
        .tab.active { border-bottom: 3px solid #0078d4; color: #0078d4; }
        .filters { display: flex; gap: 15px; margin-bottom: 20px; background: #f1f3f5; padding: 15px; border-radius: 6px; }
        input, select { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; background: #0078d4; color: white; padding: 12px; cursor: pointer; }
        td { padding: 10px; border-bottom: 1px solid #eee; font-size: 14px; }
        .btn-copy { background: #0078d4; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Entra ID Group Mapping</h1>
        <div class="tabs">
            <div id="t1" class="tab active" onclick="setTab('with')">With Members</div>
            <div id="t2" class="tab" onclick="setTab('without')">Empty Groups</div>
        </div>
        <div class="filters">
            <input type="text" id="srch" onkeyup="render()" placeholder="Search groups..." style="flex-grow:2">
            <select id="cat" onchange="render()" style="flex-grow:1"></select>
        </div>
        <table>
            <thead>
                <tr>
                    <th onclick="sortTable(0)">Display Name</th>
                    <th onclick="sortTable(1)">Suggested Name</th>
                    <th>Type</th>
                    <th>Count</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="tbody"></tbody>
        </table>
    </div>

    <script id="csvData" type="text/csv">CSV_CONTENT</script>

    <script>
        let rawData = [];
        let activeMode = 'with';

        function parse() {
            const text = document.getElementById('csvData').textContent.trim();
            const lines = text.split('\n');
            const headers = lines[0].replace(/"/g, '').split(',');
            for(let i=1; i<lines.length; i++) {
                const cols = lines[i].match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g);
                if(!cols) continue;
                let obj = {};
                headers.forEach((h, idx) => obj[h.trim()] = cols[idx].replace(/"/g, '').trim());
                rawData.push(obj);
            }
        }

        function setTab(m) {
            activeMode = m;
            document.getElementById('t1').classList.toggle('active', m==='with');
            document.getElementById('t2').classList.toggle('active', m==='without');
            updateCats();
            render();
        }

        function updateCats() {
            const filtered = rawData.filter(d => activeMode === 'with' ? d.MemberCount > 0 : d.MemberCount == 0);
            const cats = [...new Set(filtered.map(d => d.Category))].sort();
            document.getElementById('cat').innerHTML = '<option value="">All Categories</option>' + 
                cats.map(c => `<option value="${c}">${c}</option>`).join('');
        }

        function render() {
            const q = document.getElementById('srch').value.toLowerCase();
            const c = document.getElementById('cat').value;
            const body = document.getElementById('tbody');
            const data = rawData.filter(d => {
                const modeMatch = activeMode === 'with' ? d.MemberCount > 0 : d.MemberCount == 0;
                const searchMatch = d.DisplayName.toLowerCase().includes(q) || d.SuggestedName.toLowerCase().includes(q);
                const catMatch = c === "" || d.Category === c;
                return modeMatch && searchMatch && catMatch;
            });

            body.innerHTML = data.map(d => `
                <tr>
                    <td>${d.DisplayName}</td>
                    <td style="font-family:monospace; color:#0078d4">${d.SuggestedName}</td>
                    <td>${d.GroupType}</td>
                    <td>${d.MemberCount}</td>
                    <td><button class="btn-copy" onclick="copy('${d.SuggestedName}')">Copy</button></td>
                </tr>
            `).join('');
        }

        function copy(t) { navigator.clipboard.writeText(t); alert('Copied!'); }

        parse();
        updateCats();
        render();
    </script>
</body>
</html>
'@

# --- 7. Final Overwrite Save ---
$FinalHtml = $HtmlTemplate.Replace("CSV_CONTENT", $CsvString)
$FinalHtml | Out-File -FilePath $ReportPath -Encoding utf8 -Force

Write-Host "`nSUCCESS: Report generated at $ReportPath" -ForegroundColor Green
